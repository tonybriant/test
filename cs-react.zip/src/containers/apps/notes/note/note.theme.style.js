const styles = theme => ({
  'portal-note-cancel-fab__icon': {
    color: theme.palette.secondary.contrastText
  }
});

export default styles;
