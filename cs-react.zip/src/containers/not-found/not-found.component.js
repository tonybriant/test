import React, { Component } from 'react';

class NotFound extends Component {
  render() {
    return <h1>Route not found</h1>;
  }
}

export default NotFound;
